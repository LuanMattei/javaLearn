/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

/**
 *
 * @author Desktop
 */
public class Vacinacao {
    private int id;
    private String nome_Vacina;
    private String unidade;
    private int primeiraDose;
    private String primeiraDoseData;
    private int segundaDose;
    private String segundaDoseData;
    
    public Vacinacao() {
    }

    public Vacinacao(String nome_Vacina, String unidade, int primeiraDose, String primeiraDoseData, int segundaDose, String segundaDoseData,int id) {
        this.nome_Vacina = nome_Vacina;
        this.unidade = unidade;
        this.primeiraDose = primeiraDose;
        this.primeiraDoseData = primeiraDoseData;
        this.segundaDose = segundaDose;
        this.segundaDoseData = segundaDoseData;
        setId(id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome_Vacina() {
        return nome_Vacina;
    }

    public String getUnidade() {
        return unidade;
    }

    public int getPrimeiraDose() {
        return primeiraDose;
    }

    public String getPrimeiraDoseData() {
        return primeiraDoseData;
    }

    public int getSegundaDose() {
        return segundaDose;
    }

    public String getSegundaDoseData() {
        return segundaDoseData;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    public void setPrimeiraDose(int primeiraDose) {
        this.primeiraDose = primeiraDose;
    }

    public void setPrimeiraDoseData(String primeiraDoseData) {
        this.primeiraDoseData = primeiraDoseData;
    }

    public void setSegundaDose(int segundaDose) {
        this.segundaDose = segundaDose;
    }

    public void setSegundaDoseData(String segundaDoseData) {
        this.segundaDoseData = segundaDoseData;
    }
    
    public void setNome_Vacina(String nome_Vacina) {
        this.nome_Vacina = nome_Vacina;
    }  
    public String showSecondDose(int prazo){
         GregorianCalendar gc = new GregorianCalendar();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        String d1 ;
        gc.add(GregorianCalendar.DAY_OF_MONTH,prazo);
        d1 = sdf1.format(gc.getTime());
        return d1;
    }
       public String today(){
        
        Date x1 = new Date();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        String dia = sdf1.format(x1);
        return dia ;
    }
       public void CadastrarCidadaoVacinado(){
        //1: Definir o comando SQL
        String sql = "INSERT INTO tb_infovacinacao(nomeVacina,unidade,primeiraDose,dataPrimeiraDose,segundaDose,dataSegundaDose,id_paciente)"
                + " VALUES(?,?,?,?,?,?,?)";
        //2: Abrir uma conexão
        ConnectionFactory factory = new ConnectionFactory(); // cria um objeto para fazer a conexão
        try(Connection c = factory.obtemConexao()){
            //3: Pré compila o comando
            PreparedStatement ps = c.prepareStatement(sql);
            //4: manda os dados para o banco de dados
            ps.setString(1, getNome_Vacina());
            ps.setString(2,getUnidade());
            ps.setInt(3,getPrimeiraDose());
            ps.setString(4, getPrimeiraDoseData());
            ps.setInt(5, getSegundaDose());
            ps.setString(6, getSegundaDoseData());
            ps.setInt(7,getId());
             //5: Executa o comando
            ps.execute();
        }
        catch(Exception e){
             e.printStackTrace();      
        }
    }
       public void aplicarSegundaDose(){
           //definir comando sql
           String sql = "UPDATE tb_infovacinacao SET dataSegundaDose = ?, segundaDose = ? WHERE id_paciente = ? ";
           // Abrir uma conexão
           ConnectionFactory factory = new ConnectionFactory();
           try (Connection c = factory.obtemConexao()){
               //Pré compila
               PreparedStatement ps = c.prepareStatement(sql);
               ps.setString(1, getSegundaDoseData());
               ps.setInt(2, getSegundaDose());
               ps.setInt(3,getId());
               ps.execute();
           }
           catch(Exception e){
               JOptionPane.showMessageDialog(null, "Erro na vacinação");
               e.printStackTrace();
           }
       }
       public void obter(){
        String sql = "Select * from tb_infovacinacao where id_paciente = ?";
        //abri conexão 
        ConnectionFactory factory = new ConnectionFactory();
        
        try (Connection c = factory.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setInt(1, getId()); 
        ResultSet rs = ps.executeQuery();
              while(rs.next()){
                  setNome_Vacina(rs.getString("nomeVacina"));
                  setPrimeiraDoseData(rs.getString("dataPrimeiraDose"));
                  setSegundaDose(rs.getInt("segundaDose"));
                  setSegundaDoseData(rs.getString("dataSegundaDose"));
                  setUnidade(rs.getString("unidade"));
            }
        }
        catch(Exception e){
            setNome_Vacina("Não foi vacinado");
            e.printStackTrace();
        }
    }
}
      

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Desktop
 */
public class Vacina {
    private String nomeVacina;
    private int qtdeDose;
    private int entreDose;
    private String fornecedor;
    private  int id;

    public Vacina(String nomeVacina, int qtdeDose, int entreDose, String fornecedor) {
        this.nomeVacina = nomeVacina;
        this.qtdeDose = qtdeDose;
        this.entreDose = entreDose;
        this.fornecedor = fornecedor;
    }

    public Vacina() {
        
    }

    public String getNomeVacina() {
        return nomeVacina;
    }

    public void setNomeVacina(String nomeVacina) {
        this.nomeVacina = nomeVacina;
    }

    public int getQtdeDose() {
        return qtdeDose;
    }

    public void setQtdeDose(int qtdeDose) {
        this.qtdeDose = qtdeDose;
    }

    public int getEntreDose() {
        return entreDose;
    }

    public void setEntreDose(int entreDose) {
        this.entreDose = entreDose;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public void CadastrarVacina(){
        //Definir comando sql
        String sql = "Insert into tb_vacina(nomeVacina,qtdeDose,prazo,fornecedor) Values (?,?,?,?)";
        //Abrir conexão
        ConnectionFactory factory = new ConnectionFactory();
        try (Connection c = factory.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1,getNomeVacina());
            ps.setInt(2,getQtdeDose());
            ps.setInt(3,getEntreDose());
            ps.setString(4,getFornecedor());
            ps.execute();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
     public void Apagar(){
        //1: Definir o comando SQL
        String sql = "delete from tb_vacina where nomeVacina = ?";
        //2: Abrir uma conexão
        ConnectionFactory factory = new ConnectionFactory(); // cria um objeto para fazer a conexão
        try(Connection c = factory.obtemConexao()){
            //3: Pré compila o comando
            PreparedStatement ps = c.prepareStatement(sql);
            //4: manda os dados para o banco de dados
            ps.setString(1,getNomeVacina());   
            //5: Executa o comando
            ps.execute();
        }
        catch(Exception e){
            
            e.printStackTrace();
        }
        
    }
     public void obter(){
        String sql = "Select * from tb_vacina where nomeVacina = ?";
        //abri conexão 
        ConnectionFactory factory = new ConnectionFactory();
        
        try (Connection c = factory.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, getNomeVacina()); 
            ResultSet rs = ps.executeQuery();
              while(rs.next()){
                  setNomeVacina(rs.getString("nomeVacina"));
                  setQtdeDose(rs.getInt("qtdeDose"));
                  setEntreDose(rs.getInt("prazo"));
                  setFornecedor(rs.getString("fornecedor"));
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
     public void atualizar(){
         String sql = "UPDATE tb_vacina set nomeVacina =?, qtdeDose = ?, prazo = ?, fornecedor = ? where nomeVacina = ?";
         ConnectionFactory factory = new ConnectionFactory();
         
         try(Connection c = factory.obtemConexao()){
             PreparedStatement ps = c.prepareStatement(sql);
             ps.setString(5, getNomeVacina()); 
             ps.setString(1, getNomeVacina());
             ps.setInt(2, getQtdeDose());
             ps.setInt(3, getEntreDose());
             ps.setString(4,getFornecedor());
             ps.execute();
         }
         catch(Exception e){
             e.printStackTrace();
         }
     }
     public String[] listarVacina(){
         ArrayList<String> vacinas = new ArrayList<String>();
         //1: Definir comando SQL
         String sql = "Select nomeVacina FROM tb_vacina";
         //2: Abrir uma conexão
         ConnectionFactory factory = new  ConnectionFactory();
         try(Connection c = factory.obtemConexao()) {
             //3: pré compila
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery();
             while(rs.next()) {
                 vacinas.add(rs.getString("nomeVacina"));
             }
         }
         catch( Exception e){
             e.printStackTrace();
         }
         return  vacinas.toArray(new String[vacinas.size()]);
     }
}
